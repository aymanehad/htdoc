<?php

namespace App\Controller\Member;

use App\Controller\Member\AppMemberController;

class CampaignCountriesController extends AppMemberController
{
}
